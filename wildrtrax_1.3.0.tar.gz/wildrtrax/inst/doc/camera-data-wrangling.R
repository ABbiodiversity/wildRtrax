## ----echo=F, eval=F, message=TRUE, include=TRUE-------------------------------
#  
#  knitr::opts_chunk$set(echo = TRUE)

## ----echo=TRUE, eval=FALSE, message=TRUE, include=TRUE------------------------
#  
#  eh14_raw <- wt_download_report(
#    project_id = 205,
#    sensor_id = "CAM",
#    report = "main",
#    weather_cols = FALSE
#  )
#  

## ----echo=TRUE, eval=FALSE, message=TRUE, include=TRUE------------------------
#  
#  # Back to the Ecosystem Health 2014 data.
#  
#  eh14_detections <- wt_ind_detect(
#    x = eh14_raw,
#    threshold = 30,
#    units = "minutes",
#    remove_human = TRUE,
#    remove_domestic = TRUE
#  )
#  

## ----echo=TRUE, eval=F, message=TRUE, include=TRUE----------------------------
#  
#  glimpse(eh14_detections, width = 75)
#  

## ----eval=FALSE, echo=TRUE, include=TRUE--------------------------------------
#  # A call to `wt_summarise_cam()`:
#  
#  eh14_summarised <- wt_summarise_cam(
#    # Supply your detection data
#    detect_data = eh14_detections,
#    # Supply your raw image data
#    raw_data = eh14_raw,
#    # Now specify the time interval you're interested in
#    time_interval = "week",
#    # What variable are you interested in?
#    variable = "detections",
#    # Your desired output format (wide or long)
#    output_format = "wide"
#  )
#  

## ----eval=FALSE, echo=TRUE, include=TRUE--------------------------------------
#  
#  library(wildrtrax)
#  
#  Sys.setenv(WT_USERNAME = "*****",
#             WT_PASSWORD = "*****")
#  wt_auth()
#  
#  
#  projects <- wt_get_download_summary("CAM") %>%
#    filter(project == "ABMI Ecosystem Health 2014") %>%
#    select(project_id) %>%
#    pull()
#  
#  raw_data <- map_dfr(.x = projects,
#                      .f = ~wt_download_report(.x, "CAM", weather_cols = F, reports = "main")
#  
#  summarised <- wt_ind_detect(raw_data, 30, "minutes") %>%
#    wt_summarise_cam(raw_data, "day", "detections", "long")
#  

